function fasst
% Function to launch FASST using 'fasst' on the command line
%__________________________________________________________________
% Copyright (C) 2012 Cyclotron Research Centre

% Written by C. Phillips, 2012.
% Cyclotron Research Centre, University of Liege, Belgium
% $Id$

crc_main

return